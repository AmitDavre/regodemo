
> Please use https://stackoverflow.com/questions/tagged/mpdf for all your general questions or troubleshooting!
> For contributing here, please see the guideline: https://github.com/mpdf/mpdf/blob/development/.github/CONTRIBUTING.md

### I found this bug / would like to have this new functionality

### This is mPDF and PHP version and environment (fpm/cli etc) I am using

### This is a PHP code snippet I use

```
<?php


```

### This is a HTML/CSS code snippet I use

```

```
